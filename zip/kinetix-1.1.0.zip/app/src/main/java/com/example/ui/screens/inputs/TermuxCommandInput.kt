package com.example.ui.screens.inputs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun TermuxCommandInput(
    params: Map<String, String>,
    onParamsChanged: (Map<String, String>) -> Unit
) {
    val command = params["command"] ?: ""
    val args = params["args"] ?: ""
    val runInBackgroundStr = params["runInBackground"] ?: "true"
    val runInBackground = runInBackgroundStr.toBoolean()

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = command,
            onValueChange = { onParamsChanged(params + ("command" to it)) },
            label = { Text("Comando / Script de Termux") },
            placeholder = { Text("ej: echo 'Hola Mundo!'") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = args,
            onValueChange = { onParamsChanged(params + ("args" to it)) },
            label = { Text("Argumentos adicionales") },
            placeholder = { Text("ej: --verbose") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.0f)) {
                Text(
                    "Ejecutar en segundo plano",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Evita abrir la ventana de terminal de Termux.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }
            Switch(
                checked = runInBackground,
                onCheckedChange = { onParamsChanged(params + ("runInBackground" to it.toString())) }
            )
        }
    }
}
