package com.example.data

import android.content.Context
import com.example.data.presets.DefaultPresets

object DefaultShortcutsProvider {
    fun getDefaultShortcuts(context: Context? = null): List<Shortcut> {
        return listOf(
            DefaultPresets.batteryLevelShortcut(context),
            DefaultPresets.shoutTextShortcut(context),
            DefaultPresets.shareModelShortcut(context),
            DefaultPresets.smartCalculatorShortcut(context)
        )
    }
}
