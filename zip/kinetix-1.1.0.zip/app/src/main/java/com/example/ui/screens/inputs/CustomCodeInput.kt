package com.example.ui.screens.inputs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CustomCodeInput(
    params: Map<String, String>,
    onParamsChanged: (Map<String, String>) -> Unit
) {
    val script = params["script"] ?: ""
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = script,
            onValueChange = { onParamsChanged(params + ("script" to it)) },
            label = { Text("Script Personalizado de Atajo") },
            modifier = Modifier.fillMaxWidth().height(150.dp),
            singleLine = false,
            maxLines = 10,
            supportingText = { Text("Escribe sentencias como SET, PRINT, RETURN, TTS.") }
        )
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            )
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    "Sintaxis Soportada:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "• PRINT \"mi mensaje\" + {resultado}\n" +
                            "• SET variable = {resultado} + \" sufijo\"\n" +
                            "• TTS \"Pronunciar texto de variable \" + variable\n" +
                            "• UPPERCASE {resultado}\n" +
                            "• RETURN variable",
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }
        }
    }
}
