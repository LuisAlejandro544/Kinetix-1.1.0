package com.example.executor

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import com.example.R
import com.example.data.ShortcutDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AssistiveTouchService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var popupManager: AssistiveTouchPopupManager? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        popupManager = AssistiveTouchPopupManager(this, windowManager)
        setupFloatingButton()
    }

    private fun setupFloatingButton() {
        val layoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        floatingView = layoutInflater.inflate(R.layout.layout_assistive_touch_button, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        try {
            windowManager?.addView(floatingView, params)
        } catch (e: Exception) {
            FileLogManager.logWarning(this, "AssistiveTouchError", "Error agregando vista flotante: ${e.localizedMessage}")
            stopSelf()
            return
        }

        floatingView?.setOnTouchListener(object : View.OnTouchListener {
            private var isClick = false

            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                if (event == null) return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isClick = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isClick = false
                        }
                        params.x = initialX + dx
                        params.y = initialY + dy
                        try {
                            windowManager?.updateViewLayout(floatingView, params)
                        } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isClick) {
                            toggleQuickPopup(params.x, params.y)
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun toggleQuickPopup(touchX: Int, touchY: Int) {
        val manager = popupManager ?: return
        if (manager.isPopupShowing) {
            manager.dismissPopup()
            return
        }

        serviceScope.launch(Dispatchers.IO) {
            val db = ShortcutDatabase.getDatabase(applicationContext)
            val shortcuts = db.shortcutDao().getAllShortcutsList()

            withContext(Dispatchers.Main) {
                manager.showPopup(shortcuts, touchX, touchY)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        popupManager?.dismissPopup()
        if (floatingView != null) {
            try {
                windowManager?.removeView(floatingView)
            } catch (_: Exception) {}
            floatingView = null
        }
        serviceScope.cancel()
    }

    companion object {
        fun start(context: Context) {
            try {
                val intent = Intent(context, AssistiveTouchService::class.java)
                context.startService(intent)
            } catch (e: Exception) {
                FileLogManager.logWarning(context, "AssistiveTouchStartError", e.localizedMessage ?: "")
            }
        }

        fun stop(context: Context) {
            try {
                val intent = Intent(context, AssistiveTouchService::class.java)
                context.stopService(intent)
            } catch (_: Exception) {}
        }
    }
}
