package com.example.data.presets

import android.content.Context
import com.example.R
import com.example.data.ActionData
import com.example.data.ActionType
import com.example.data.Shortcut

object DefaultPresets {
    fun batteryLevelShortcut(context: Context? = null) = Shortcut(
        name = context?.getString(R.string.preset_battery_name) ?: "Spoken Battery Level",
        description = context?.getString(R.string.preset_battery_desc) ?: "Checks battery percentage, reads it aloud, and posts a notification.",
        iconName = "battery",
        colorHex = "#34C759", // Green
        actions = listOf(
            ActionData(ActionType.SYSTEM_INFO, mapOf("infoType" to "Battery Level")),
            ActionData(ActionType.SPEAK_TEXT, mapOf("text" to "Battery level is {resultado}")),
            ActionData(ActionType.SHOW_NOTIFICATION, mapOf("title" to "Battery Status", "message" to "Current battery level is {resultado}"))
        )
    )

    fun shoutTextShortcut(context: Context? = null) = Shortcut(
        name = context?.getString(R.string.preset_shout_name) ?: "Shout Text",
        description = context?.getString(R.string.preset_shout_desc) ?: "Prompts for text, converts to UPPERCASE, speaks it aloud, and alerts.",
        iconName = "volume",
        colorHex = "#FF9500", // Orange
        actions = listOf(
            ActionData(ActionType.TEXT_INPUT, mapOf("prompt" to "What text do you want to shout?", "defaultValue" to "Hello Android")),
            ActionData(ActionType.TEXT_TRANSFORM, mapOf("transformType" to "UPPERCASE")),
            ActionData(ActionType.SPEAK_TEXT, mapOf("text" to "{resultado}")),
            ActionData(ActionType.ALERT_DIALOG, mapOf("title" to "Shouted Text", "message" to "Spoken: {resultado}"))
        )
    )

    fun shareModelShortcut(context: Context? = null) = Shortcut(
        name = context?.getString(R.string.preset_share_model_name) ?: "Share Device Model",
        description = context?.getString(R.string.preset_share_model_desc) ?: "Gets device phone model and opens native share dialog.",
        iconName = "share",
        colorHex = "#007AFF", // Blue
        actions = listOf(
            ActionData(ActionType.SYSTEM_INFO, mapOf("infoType" to "Device Model")),
            ActionData(ActionType.SHARE_TEXT, mapOf("text" to "📱 Hello! I am using a {resultado} with Kinetix."))
        )
    )

    fun smartCalculatorShortcut(context: Context? = null) = Shortcut(
        name = context?.getString(R.string.preset_calc_name) ?: "Smart Calculator",
        description = context?.getString(R.string.preset_calc_desc) ?: "Prompts for a base number, adds 5, multiplies by 10, and shows output.",
        iconName = "calculator",
        colorHex = "#AF52DE", // Purple
        actions = listOf(
            ActionData(ActionType.TEXT_INPUT, mapOf("prompt" to "Enter a starting number:", "defaultValue" to "5")),
            ActionData(ActionType.MATH_OP, mapOf("operation" to "Add", "operand" to "5")),
            ActionData(ActionType.MATH_OP, mapOf("operation" to "Multiply", "operand" to "10")),
            ActionData(ActionType.ALERT_DIALOG, mapOf("title" to "Math Result", "message" to "The final result of (X + 5) * 10 is: {resultado}"))
        )
    )
}
