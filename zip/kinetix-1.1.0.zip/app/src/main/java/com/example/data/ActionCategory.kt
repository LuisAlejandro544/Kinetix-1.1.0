package com.example.data

import android.content.Context
import androidx.annotation.StringRes
import com.example.R

enum class ActionCategory(
    val displayName: String,
    @StringRes val nameRes: Int
) {
    AUDIO_VISUAL("Audio & Visual", R.string.category_audio_visual),
    SYSTEM("System & Info", R.string.category_system),
    FILES("Files & Storage", R.string.category_files),
    LOGIC("Logic & Flow", R.string.category_logic),
    POWER_ANDROID("Hardware & Accessibility", R.string.category_power_android),
    DEVELOPER("Developer & Advanced", R.string.category_developer);

    fun getDisplayName(context: Context): String = context.getString(nameRes)
}

fun ActionType.getCategory(): ActionCategory {
    return when (this) {
        ActionType.SPEAK_TEXT,
        ActionType.SHOW_NOTIFICATION,
        ActionType.PLAY_SOUND,
        ActionType.SET_VOLUME,
        ActionType.SET_RINGER_MODE -> ActionCategory.AUDIO_VISUAL

        ActionType.SYSTEM_INFO,
        ActionType.OPEN_URL,
        ActionType.OPEN_APP,
        ActionType.SET_BRIGHTNESS -> ActionCategory.SYSTEM

        ActionType.WRITE_FILE,
        ActionType.READ_FILE,
        ActionType.APPEND_FILE -> ActionCategory.FILES

        ActionType.TEXT_INPUT,
        ActionType.TEXT_TRANSFORM,
        ActionType.ALERT_DIALOG,
        ActionType.MATH_OP,
        ActionType.SHARE_TEXT,
        ActionType.CONDITIONAL -> ActionCategory.LOGIC

        ActionType.VIBRATE,
        ActionType.ACCESSIBILITY_ACTION,
        ActionType.BACKGROUND_CAMERA_CAPTURE,
        ActionType.SIMULATE_GESTURES,
        ActionType.CLIPBOARD_SILENT -> ActionCategory.POWER_ANDROID

        ActionType.EXEC_JAVASCRIPT,
        ActionType.TERMUX_COMMAND,
        ActionType.CUSTOM_CODE,
        ActionType.HTTP_REQUEST -> ActionCategory.DEVELOPER
    }
}
