package com.example.ui.screens.inputs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimulateGesturesInput(
    params: Map<String, String>,
    onParamsChanged: (Map<String, String>) -> Unit
) {
    val gestureType = params["gestureType"] ?: "TAP"
    val x1 = params["x1"] ?: "500"
    val y1 = params["y1"] ?: "1000"
    val x2 = params["x2"] ?: "500"
    val y2 = params["y2"] ?: "500"
    val duration = params["duration"] ?: "300"

    val options = listOf(
        "TAP" to "Simular Toque",
        "SWIPE" to "Simular Desplazamiento"
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            "Tipo de gesto a simular:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(options.size) { index ->
                val opt = options[index]
                val isSelected = gestureType == opt.first
                FilterChip(
                    selected = isSelected,
                    onClick = { onParamsChanged(params + ("gestureType" to opt.first)) },
                    label = { Text(opt.second, fontSize = 11.sp) }
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = x1,
                onValueChange = { onParamsChanged(params + ("x1" to it)) },
                label = { Text("X (Inicio)") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
                value = y1,
                onValueChange = { onParamsChanged(params + ("y1" to it)) },
                label = { Text("Y (Inicio)") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }

        if (gestureType == "SWIPE") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = x2,
                    onValueChange = { onParamsChanged(params + ("x2" to it)) },
                    label = { Text("X (Fin)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    value = y2,
                    onValueChange = { onParamsChanged(params + ("y2" to it)) },
                    label = { Text("Y (Fin)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
        }

        OutlinedTextField(
            value = duration,
            onValueChange = { onParamsChanged(params + ("duration" to it)) },
            label = { Text("Duración (milisegundos)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )

        Text(
            "Nota: Requiere tener activo el servicio de accesibilidad de Kinetix. Utiliza las coordenadas de píxeles reales de tu pantalla.",
            style = MaterialTheme.typography.bodySmall,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.outline,
            lineHeight = 14.sp
        )
    }
}
