package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ActionType
import com.example.executor.ShortcutAccessibilityService
import com.example.ui.screens.actionpicker.AccessibilityLockAlert
import com.example.ui.screens.actionpicker.ActionPickerCategoryChips
import com.example.ui.screens.actionpicker.ActionPickerItemRow
import com.example.ui.screens.actionpicker.ActionPickerSearchBar
import com.example.ui.screens.actionpicker.getCategoryForAction
import com.example.ui.screens.actionpicker.requiresAccessibility

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActionPickerDial(
    onDismiss: () -> Unit,
    onActionSelected: (ActionType) -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Todos") }
    var showAccessibilityLockAlert by remember { mutableStateOf<ActionType?>(null) }

    val isAccessibilityActive = ShortcutAccessibilityService.isServiceRunning()

    val categories = listOf("Todos", "Voz y Sonido", "Sistema", "Archivos y Datos", "Lógica y Código")

    val filteredActions = remember(searchQuery, selectedCategory) {
        ActionType.values().filter { type ->
            val matchesCategory = selectedCategory == "Todos" || getCategoryForAction(type) == selectedCategory
            val matchesSearch = type.displayName.contains(searchQuery, ignoreCase = true) ||
                    type.description.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    "Elige una Acción",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    "Agrega automatizaciones a tu flujo",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Search Input Bar
                ActionPickerSearchBar(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it }
                )

                // Category Chips Scrollable Row
                ActionPickerCategoryChips(
                    categories = categories,
                    selectedCategory = selectedCategory,
                    onCategorySelected = { selectedCategory = it }
                )

                // Filtered actions list
                if (filteredActions.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.SearchOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "No se encontraron acciones",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.outline,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .testTag("action_picker_list"),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredActions) { type ->
                            val isLocked = requiresAccessibility(type) && !isAccessibilityActive
                            ActionPickerItemRow(
                                type = type,
                                isLocked = isLocked,
                                onClick = {
                                    if (isLocked) {
                                        showAccessibilityLockAlert = type
                                    } else {
                                        onActionSelected(type)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        },
        shape = RoundedCornerShape(24.dp)
    )

    // Alert Dialog overlay when selecting a locked action
    showAccessibilityLockAlert?.let { type ->
        AccessibilityLockAlert(
            type = type,
            context = context,
            onDismiss = { showAccessibilityLockAlert = null }
        )
    }
}
