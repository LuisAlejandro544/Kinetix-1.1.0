package com.example.ui.screens.inputs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ExecJavascriptInput(
    params: Map<String, String>,
    onParamsChanged: (Map<String, String>) -> Unit
) {
    val code = params["code"] ?: ""
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = code,
            onValueChange = { onParamsChanged(params + ("code" to it)) },
            label = { Text("Código JavaScript (QuickJS)") },
            modifier = Modifier.fillMaxWidth().height(150.dp),
            singleLine = false,
            maxLines = 10,
            supportingText = { Text("La última línea o expresión evaluada es el resultado.") }
        )
        Text(
            "Ejecuta código JavaScript estándar de manera segura. Puedes usar variables reemplazables como {resultado} o escribir lógica JS de forma nativa.",
            style = MaterialTheme.typography.bodySmall,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.outline,
            lineHeight = 14.sp
        )
    }
}
