package com.example.ui.screens.onboarding

import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.executor.ShortcutAccessibilityService

@Composable
fun PermissionsStep() {
    val context = LocalContext.current
    
    // Permission states
    var isCameraGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    
    var isNotificationGranted by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    var isAccessibilityActive by remember {
        mutableStateOf(ShortcutAccessibilityService.isServiceRunning())
    }

    var showAccessibilityDialog by remember { mutableStateOf(false) }

    // Launchers
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isCameraGranted = granted
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isNotificationGranted = granted
    }

    // Refresh accessibility state when returning to the app
    DisposableEffect(Unit) {
        isAccessibilityActive = ShortcutAccessibilityService.isServiceRunning()
        onDispose { }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Permisos Bajo tu Control",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Text(
            text = "Tú decides qué permisos otorgar. No te obligamos a activar nada: habilita solo las capacidades que necesites usar.",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Notifications Permission Card
            PermissionCard(
                icon = Icons.Default.Notifications,
                title = "Notificaciones",
                description = "Requerido para avisarte sobre la ejecución y finalización de tus atajos.",
                isGranted = isNotificationGranted,
                onClick = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        notificationLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            )

            // Camera Permission Card
            PermissionCard(
                icon = Icons.Default.PhotoCamera,
                title = "Cámara (Opcional)",
                description = "Solo es necesario si vas a utilizar el bloque de acción de captura en segundo plano.",
                isGranted = isCameraGranted,
                onClick = {
                    cameraLauncher.launch(android.Manifest.permission.CAMERA)
                }
            )

            // Accessibility Service Card
            PermissionCard(
                icon = Icons.Default.AccessibilityNew,
                title = "Servicio de Accesibilidad",
                description = "Permite a Kinetix simular toques físicos y gestos automáticos de forma local y segura.",
                isGranted = isAccessibilityActive,
                actionLabel = if (isAccessibilityActive) "Activo" else "Habilitar",
                onClick = {
                    if (!isAccessibilityActive) {
                        showAccessibilityDialog = true
                    }
                }
            )
        }
    }

    if (showAccessibilityDialog) {
        AccessibilityDialog(
            context = context,
            onDismiss = { showAccessibilityDialog = false }
        )
    }
}
