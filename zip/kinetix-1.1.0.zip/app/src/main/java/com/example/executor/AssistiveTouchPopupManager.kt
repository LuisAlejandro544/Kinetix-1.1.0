package com.example.executor

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.example.R
import com.example.data.Shortcut

class AssistiveTouchPopupManager(
    private val context: Context,
    private val windowManager: WindowManager?
) {
    private var popupView: View? = null
    var isPopupShowing: Boolean = false
        private set

    fun showPopup(shortcuts: List<Shortcut>, xPos: Int, yPos: Int) {
        if (isPopupShowing) dismissPopup()

        val layoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        popupView = layoutInflater.inflate(R.layout.layout_assistive_touch_menu, null)

        val container = popupView?.findViewById<LinearLayout>(R.id.assistive_menu_container)

        if (shortcuts.isEmpty()) {
            val emptyTv = TextView(context).apply {
                text = "No hay atajos creados"
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(24, 24, 24, 24)
            }
            container?.addView(emptyTv)
        } else {
            shortcuts.take(6).forEach { shortcut ->
                val btn = TextView(context).apply {
                    text = "⚡ ${shortcut.name}"
                    setTextColor(0xFF34D399.toInt())
                    setPadding(32, 20, 32, 20)
                    textSize = 14f
                    setOnClickListener {
                        BackgroundExecutor.executeShortcutInBackground(context.applicationContext, shortcut)
                        dismissPopup()
                    }
                }
                container?.addView(btn)
            }
        }

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val popupParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = xPos
            y = yPos + 120
        }

        try {
            windowManager?.addView(popupView, popupParams)
            isPopupShowing = true
        } catch (e: Exception) {
            FileLogManager.logWarning(context, "AssistiveTouchPopupError", e.localizedMessage ?: "")
        }
    }

    fun dismissPopup() {
        if (isPopupShowing && popupView != null) {
            try {
                windowManager?.removeView(popupView)
            } catch (_: Exception) {}
            popupView = null
            isPopupShowing = false
        }
    }
}
