package com.example.ui.screens.inputs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClipboardSilentInput(
    params: Map<String, String>,
    onParamsChanged: (Map<String, String>) -> Unit
) {
    val operation = params["operation"] ?: "WRITE"
    val text = params["text"] ?: "{resultado}"

    val options = listOf(
        "WRITE" to "Copiar al portapapeles",
        "READ" to "Leer del portapapeles"
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            "Operación del Portapapeles:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(options.size) { index ->
                val opt = options[index]
                val isSelected = operation == opt.first
                FilterChip(
                    selected = isSelected,
                    onClick = { onParamsChanged(params + ("operation" to opt.first)) },
                    label = { Text(opt.second, fontSize = 11.sp) }
                )
            }
        }

        if (operation == "WRITE") {
            OutlinedTextField(
                value = text,
                onValueChange = { onParamsChanged(params + ("text" to it)) },
                label = { Text("Texto a copiar") },
                modifier = Modifier.fillMaxWidth(),
                supportingText = { Text("Puedes usar {resultado} para copiar el output del paso anterior.") }
            )
        } else {
            Text(
                "La operación de lectura extraerá el texto actual del portapapeles y lo pasará como entrada al siguiente paso de la automatización.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
    }
}
