package com.example.data

import android.content.Context
import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.R

enum class ActionType(
    @StringRes val nameRes: Int,
    @StringRes val descRes: Int
) {
    SPEAK_TEXT(R.string.action_speak_text_name, R.string.action_speak_text_desc),
    SHOW_NOTIFICATION(R.string.action_show_notification_name, R.string.action_show_notification_desc),
    VIBRATE(R.string.action_vibrate_name, R.string.action_vibrate_desc),
    OPEN_URL(R.string.action_open_url_name, R.string.action_open_url_desc),
    TEXT_INPUT(R.string.action_text_input_name, R.string.action_text_input_desc),
    TEXT_TRANSFORM(R.string.action_text_transform_name, R.string.action_text_transform_desc),
    ALERT_DIALOG(R.string.action_alert_dialog_name, R.string.action_alert_dialog_desc),
    SYSTEM_INFO(R.string.action_system_info_name, R.string.action_system_info_desc),
    MATH_OP(R.string.action_math_op_name, R.string.action_math_op_desc),
    SHARE_TEXT(R.string.action_share_text_name, R.string.action_share_text_desc),
    CONDITIONAL(R.string.action_conditional_name, R.string.action_conditional_desc),
    OPEN_APP(R.string.action_open_app_name, R.string.action_open_app_desc),
    SET_VOLUME(R.string.action_set_volume_name, R.string.action_set_volume_desc),
    SET_RINGER_MODE(R.string.action_set_ringer_mode_name, R.string.action_set_ringer_mode_desc),
    WRITE_FILE(R.string.action_write_file_name, R.string.action_write_file_desc),
    READ_FILE(R.string.action_read_file_name, R.string.action_read_file_desc),
    APPEND_FILE(R.string.action_append_file_name, R.string.action_append_file_desc),
    SET_BRIGHTNESS(R.string.action_set_brightness_name, R.string.action_set_brightness_desc),
    ACCESSIBILITY_ACTION(R.string.action_accessibility_action_name, R.string.action_accessibility_action_desc),
    PLAY_SOUND(R.string.action_play_sound_name, R.string.action_play_sound_desc),
    EXEC_JAVASCRIPT(R.string.action_exec_javascript_name, R.string.action_exec_javascript_desc),
    TERMUX_COMMAND(R.string.action_termux_command_name, R.string.action_termux_command_desc),
    CUSTOM_CODE(R.string.action_custom_code_name, R.string.action_custom_code_desc),
    BACKGROUND_CAMERA_CAPTURE(R.string.action_background_camera_capture_name, R.string.action_background_camera_capture_desc),
    SIMULATE_GESTURES(R.string.action_simulate_gestures_name, R.string.action_simulate_gestures_desc),
    CLIPBOARD_SILENT(R.string.action_clipboard_silent_name, R.string.action_clipboard_silent_desc),
    HTTP_REQUEST(R.string.action_http_request_name, R.string.action_http_request_desc);

    fun getDisplayName(context: Context): String = context.getString(nameRes)
    fun getDescription(context: Context): String = context.getString(descRes)

    val displayName: String
        get() = when (this) {
            SPEAK_TEXT -> "Text to Speech (TTS)"
            SHOW_NOTIFICATION -> "Show Notification"
            VIBRATE -> "Vibrate Device"
            OPEN_URL -> "Open Web Page"
            TEXT_INPUT -> "Request Text Input"
            TEXT_TRANSFORM -> "Transform Text"
            ALERT_DIALOG -> "Show Alert Dialog"
            SYSTEM_INFO -> "Get System Info"
            MATH_OP -> "Math Operation"
            SHARE_TEXT -> "Share Text"
            CONDITIONAL -> "Conditional Logic (If / Else)"
            OPEN_APP -> "Open Application"
            SET_VOLUME -> "Set Volume"
            SET_RINGER_MODE -> "Change Sound Mode"
            WRITE_FILE -> "Write File"
            READ_FILE -> "Read File"
            APPEND_FILE -> "Append to File"
            SET_BRIGHTNESS -> "Adjust Screen Brightness"
            ACCESSIBILITY_ACTION -> "Accessibility Action"
            PLAY_SOUND -> "Play Sound"
            EXEC_JAVASCRIPT -> "Execute JavaScript (QuickJS)"
            TERMUX_COMMAND -> "Run Termux Command"
            CUSTOM_CODE -> "Custom Script (Kinetix Block)"
            BACKGROUND_CAMERA_CAPTURE -> "Capture Camera Photo"
            SIMULATE_GESTURES -> "Simulate Tap/Swipe"
            CLIPBOARD_SILENT -> "Silent Clipboard"
            HTTP_REQUEST -> "HTTP Request / Webhook"
        }

    val icon: ImageVector
        get() = when (this) {
            SPEAK_TEXT -> Icons.AutoMirrored.Filled.VolumeUp
            SHOW_NOTIFICATION -> Icons.Default.Notifications
            VIBRATE -> Icons.Default.Vibration
            OPEN_URL -> Icons.Default.Language
            TEXT_INPUT -> Icons.Default.Edit
            TEXT_TRANSFORM -> Icons.Default.Transform
            ALERT_DIALOG -> Icons.Default.Info
            SYSTEM_INFO -> Icons.Default.Settings
            MATH_OP -> Icons.Default.Calculate
            SHARE_TEXT -> Icons.Default.Share
            CONDITIONAL -> Icons.AutoMirrored.Filled.CallSplit
            OPEN_APP -> Icons.Default.Apps
            SET_VOLUME -> Icons.AutoMirrored.Filled.VolumeDown
            SET_RINGER_MODE -> Icons.AutoMirrored.Filled.VolumeOff
            WRITE_FILE -> Icons.Default.Save
            READ_FILE -> Icons.Default.Description
            APPEND_FILE -> Icons.AutoMirrored.Filled.NoteAdd
            SET_BRIGHTNESS -> Icons.Default.LightMode
            ACCESSIBILITY_ACTION -> Icons.Default.Accessibility
            PLAY_SOUND -> Icons.Default.MusicNote
            EXEC_JAVASCRIPT -> Icons.Default.Code
            TERMUX_COMMAND -> Icons.Default.Terminal
            CUSTOM_CODE -> Icons.Default.DeveloperMode
            BACKGROUND_CAMERA_CAPTURE -> Icons.Default.PhotoCamera
            SIMULATE_GESTURES -> Icons.Default.TouchApp
            CLIPBOARD_SILENT -> Icons.Default.ContentPaste
            HTTP_REQUEST -> Icons.Default.CloudSync
        }

    val description: String
        get() = when (this) {
            SPEAK_TEXT -> "Lee texto en voz alta utilizando el motor de síntesis de voz de Android."
            SHOW_NOTIFICATION -> "Muestra una notificación en la barra de estado de Android."
            VIBRATE -> "Hace vibrar el teléfono durante los milisegundos especificados."
            OPEN_URL -> "Abre una dirección web o URL en el navegador de internet."
            TEXT_INPUT -> "Muestra un diálogo solicitando una entrada de texto al usuario."
            TEXT_TRANSFORM -> "Modifica el texto recibido (MAYÚSCULAS, minúsculas, reverso)."
            ALERT_DIALOG -> "Muestra un diálogo pop-up de alerta con un mensaje."
            SYSTEM_INFO -> "Obtiene información en tiempo real como batería o modelo del dispositivo."
            MATH_OP -> "Aplica sumas, restas, multiplicaciones o divisiones al número de entrada."
            SHARE_TEXT -> "Abre el diálogo nativo de compartir para enviar el texto a otras aplicaciones."
            CONDITIONAL -> "Evalúa una condición de texto o número. Si es verdadera, devuelve un valor; si no, devuelve otro."
            OPEN_APP -> "Espera el tiempo seleccionado y luego abre una aplicación instalada en el dispositivo."
            SET_VOLUME -> "Cambia el volumen de un canal específico (Multimedia, Timbre, Alarma, etc.) a un porcentaje del 0 al 100."
            SET_RINGER_MODE -> "Cambia entre los modos de sonido: Sonido, Vibrar, o Silenciar (No Molestar)."
            WRITE_FILE -> "Guarda texto en un archivo local en el almacenamiento interno de la app."
            READ_FILE -> "Lee el contenido completo de un archivo local de texto."
            APPEND_FILE -> "Añade texto o registros de logs al final de un archivo local de texto."
            SET_BRIGHTNESS -> "Ajusta el brillo general de la pantalla (0% a 100%). Requiere permisos del sistema."
            ACCESSIBILITY_ACTION -> "Ejecuta acciones de accesibilidad como Atrás, Inicio, Abrir Notificaciones, Ajustes Rápidos o Bloquear Pantalla."
            PLAY_SOUND -> "Reproduce un sonido o tono del sistema al estilo de los atajos de iPhone."
            EXEC_JAVASCRIPT -> "Ejecuta código JavaScript usando un motor QuickJS embebido ultraligero y seguro."
            TERMUX_COMMAND -> "Envía y ejecuta comandos en Termux utilizando su API de integración y emisión de scripts."
            CUSTOM_CODE -> "Crea una acción totalmente personalizada escribiendo un script con lógica, variables y salidas."
            BACKGROUND_CAMERA_CAPTURE -> "Captura una foto de la cámara frontal o trasera en segundo plano de manera silenciosa."
            SIMULATE_GESTURES -> "Simula un toque o deslizamiento (swipe) en coordenadas específicas de la pantalla."
            CLIPBOARD_SILENT -> "Lee o escribe texto en el portapapeles del sistema de manera silenciosa."
            HTTP_REQUEST -> "Realiza solicitudes HTTP (GET, POST, PUT, DELETE, PATCH) con cabeceras y cuerpo personalizables a APIs o webhooks."
        }

    val defaultParams: Map<String, String>
        get() = when (this) {
            SPEAK_TEXT -> mapOf("text" to "{resultado}", "speechRate" to "1.0")
            SHOW_NOTIFICATION -> mapOf("title" to "Kinetix", "message" to "{resultado}")
            VIBRATE -> mapOf("duration" to "500")
            OPEN_URL -> mapOf("url" to "https://google.com")
            TEXT_INPUT -> mapOf("prompt" to "Escribe un mensaje para continuar:", "defaultValue" to "")
            TEXT_TRANSFORM -> mapOf("transformType" to "UPPERCASE")
            ALERT_DIALOG -> mapOf("title" to "Alerta de Kinetix", "message" to "{resultado}")
            SYSTEM_INFO -> mapOf("infoType" to "Battery Level")
            MATH_OP -> mapOf("operation" to "Add", "operand" to "1")
            SHARE_TEXT -> mapOf("text" to "{resultado}")
            CONDITIONAL -> mapOf("value" to "{resultado}", "operator" to "Equals", "compareValue" to "", "thenValue" to "Sí", "elseValue" to "No")
            OPEN_APP -> mapOf("packageName" to "", "appName" to "", "delay" to "3")
            SET_VOLUME -> mapOf("streamType" to "Music", "volumePercent" to "50")
            SET_RINGER_MODE -> mapOf("ringerMode" to "Vibrate")
            WRITE_FILE -> mapOf("fileName" to "kinetix_datos.txt", "content" to "{resultado}")
            READ_FILE -> mapOf("fileName" to "kinetix_datos.txt")
            APPEND_FILE -> mapOf("fileName" to "kinetix_log.txt", "content" to "{resultado}")
            SET_BRIGHTNESS -> mapOf("brightnessPercent" to "70")
            ACCESSIBILITY_ACTION -> mapOf("actionType" to "Back")
            PLAY_SOUND -> mapOf("soundType" to "Beep")
            EXEC_JAVASCRIPT -> mapOf("code" to "const input = '{resultado}';\n// Tu código JS aquí. Retorna el resultado final al final del script.\ninput.toUpperCase() + ' (QuickJS)';")
            TERMUX_COMMAND -> mapOf("command" to "echo 'Hola desde Kinetix!'; date", "args" to "", "runInBackground" to "true")
            CUSTOM_CODE -> mapOf("script" to "PRINT 'Resultado anterior: ' + {resultado};\nSET output = 'Resultado personalizado: ' + {resultado};\nRETURN output;")
            BACKGROUND_CAMERA_CAPTURE -> mapOf("cameraType" to "BACK")
            SIMULATE_GESTURES -> mapOf("gestureType" to "TAP", "x1" to "500", "y1" to "1000", "x2" to "500", "y2" to "500", "duration" to "300")
            CLIPBOARD_SILENT -> mapOf("operation" to "WRITE", "text" to "{resultado}")
            HTTP_REQUEST -> mapOf("url" to "https://httpbin.org/get", "method" to "GET", "headers" to "Content-Type: application/json", "body" to "", "timeout" to "10")
        }

    companion object {
        const val input = "\${input}"
        const val friendlyInput = "{resultado}"
    }
}
